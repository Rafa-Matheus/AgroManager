﻿namespace EmbeddedExcel {
	partial class Form1 {
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components=null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing) {
			if(disposing&&(components!=null)) {
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			this.splitContainer1=new System.Windows.Forms.SplitContainer();
			this.button1=new System.Windows.Forms.Button();
			this.openFileDialog1=new System.Windows.Forms.OpenFileDialog();
			this.checkBox1=new System.Windows.Forms.CheckBox();
			this.excelWrapper1=new EmbeddedExcel.ExcelWrapper();
			this.splitContainer1.Panel1.SuspendLayout();
			this.splitContainer1.Panel2.SuspendLayout();
			this.splitContainer1.SuspendLayout();
			this.SuspendLayout();
			// 
			// splitContainer1
			// 
			this.splitContainer1.Dock=System.Windows.Forms.DockStyle.Fill;
			this.splitContainer1.Location=new System.Drawing.Point(0,0);
			this.splitContainer1.Name="splitContainer1";
			// 
			// splitContainer1.Panel1
			// 
			this.splitContainer1.Panel1.Controls.Add(this.checkBox1);
			this.splitContainer1.Panel1.Controls.Add(this.button1);
			// 
			// splitContainer1.Panel2
			// 
			this.splitContainer1.Panel2.Controls.Add(this.excelWrapper1);
			this.splitContainer1.Size=new System.Drawing.Size(638,494);
			this.splitContainer1.SplitterDistance=175;
			this.splitContainer1.TabIndex=1;
			// 
			// button1
			// 
			this.button1.Location=new System.Drawing.Point(46,28);
			this.button1.Name="button1";
			this.button1.Size=new System.Drawing.Size(75,23);
			this.button1.TabIndex=0;
			this.button1.Text="Open file";
			this.button1.UseVisualStyleBackColor=true;
			this.button1.Click+=new System.EventHandler(this.button1_Click);
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.FileName="openFileDialog1";
			this.openFileDialog1.Filter="Excel Files | *.xls";
			// 
			// checkBox1
			// 
			this.checkBox1.AutoSize=true;
			this.checkBox1.Location=new System.Drawing.Point(24,74);
			this.checkBox1.Name="checkBox1";
			this.checkBox1.Size=new System.Drawing.Size(121,17);
			this.checkBox1.TabIndex=1;
			this.checkBox1.Text="CommandBar visible";
			this.checkBox1.UseVisualStyleBackColor=true;
			this.checkBox1.CheckedChanged+=new System.EventHandler(this.checkBox1_CheckedChanged);
			// 
			// excelWrapper1
			// 
			this.excelWrapper1.Dock=System.Windows.Forms.DockStyle.Fill;
			this.excelWrapper1.Location=new System.Drawing.Point(0,0);
			this.excelWrapper1.Name="excelWrapper1";
			this.excelWrapper1.Size=new System.Drawing.Size(459,494);
			this.excelWrapper1.TabIndex=0;
			this.excelWrapper1.ToolBarVisible=false;
			// 
			// Form1
			// 
			this.AutoScaleDimensions=new System.Drawing.SizeF(6F,13F);
			this.AutoScaleMode=System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize=new System.Drawing.Size(638,494);
			this.Controls.Add(this.splitContainer1);
			this.Name="Form1";
			this.Text="Form1";
			this.splitContainer1.Panel1.ResumeLayout(false);
			this.splitContainer1.Panel1.PerformLayout();
			this.splitContainer1.Panel2.ResumeLayout(false);
			this.splitContainer1.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private ExcelWrapper excelWrapper1;
		private System.Windows.Forms.SplitContainer splitContainer1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.CheckBox checkBox1;
	}
}

